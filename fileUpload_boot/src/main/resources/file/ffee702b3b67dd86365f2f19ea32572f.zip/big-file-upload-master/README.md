# BigFileUpload

#### 介绍
springboot和vue3实现大文件分片上传

## 演示视频
* https://www.bilibili.com/video/BV1CA411f7np/?vd_source=1fe29350b37642fa583f709b9ae44b35
## 详解博客
* https://blog.csdn.net/weixin_50799082/article/details/128547482
